Installation
-
 - Register for a "Mana World" account on your computer: https://www.themanaworld.org/register 
 - Copy the "manaplus" folder to your sdcard ("/switch/manaplus")
 - Launch the game, login and enjoy

Default buttons mapping:
-
```
KEY_A               JButton1    "target + move + attack"
KEY_B               JButton2    "stop attack / sit"
KEY_X               JButton3    "pickup"
KEY_Y               JButton4    "move to target"
KEY_LSTICK          JButton5
KEY_RSTICK          JButton6
KEY_L               JButton7    "target NPC"
KEY_R               JButton8    "target monster"
KEY_ZL              JButton9    "talk (NPCS)"
KEY_ZR              JButton10   "attack (without move)"
KEY_PLUS            JButton11   "toggle Chat"
KEY_MINUS           JButton12   "toggle Quit (window)"
KEY_DLEFT           JButton13
KEY_DUP             JButton14
KEY_DRIGHT          JButton15
KEY_DDOWN           JButton16
KEY_LSTICK_LEFT     JButton17
KEY_LSTICK_UP       JButton18
KEY_LSTICK_RIGHT    JButton19
KEY_LSTICK_DOWN     JButton20
KEY_RSTICK_LEFT     JButton21
KEY_RSTICK_UP       JButton22
KEY_RSTICK_RIGHT    JButton23
KEY_RSTICK_DOWN     JButton24
```

Building
-
```
git clone https://github.com/Cpasjuste/ManaPlus.git
cd ManaPlus
cp packaging/switch/CMakeLists.txt.switch CMakeLists.txt
mkdir cmake-build-release && cd cmake-build-release
cmake -DPLATFORM_SWITCH=ON -DCMAKE_BUILD_TYPE=Release ../
make ManaPlus.nro
```